def test_a(testbed):
    print "test a"
    print testbed
    print testbed.attributes
    print testbed.attributes['my-virtualbox']['vm_ip']

def test_b():
    print "test b"