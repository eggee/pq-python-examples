def test_c():
    print "test c"

def test_d():
    print "test d"